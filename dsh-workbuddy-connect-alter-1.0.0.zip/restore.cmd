@echo off
chcp 65001 >nul
title dsh-workbuddy-connect-alter 1.0.0 - Restore
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo   Node.js not found. Install Node.js LTS ^(https://nodejs.org^) and run this again.
  echo.
  pause
  exit /b 1
)
node install.js --restore
echo.
pause
