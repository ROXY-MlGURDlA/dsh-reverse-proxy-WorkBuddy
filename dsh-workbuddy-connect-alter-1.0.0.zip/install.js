#!/usr/bin/env node
/**
 * dsh-workbuddy-connect-alter 1.0.0 · 安装器
 *
 * 本包基于 dsh-workbuddy-connect 0.7.9（作者 corrinehu，MIT 许可）修改，
 * 非官方发行版。上游：https://github.com/corrinehu/dsh-workbuddy-connect
 *
 * 作用：把 payload/lib 下三个已打补丁的文件，覆盖到本机 DSH 已安装的
 * dsh-workbuddy-connect 插件目录里，并留下 .bak-dshfix 备份。
 *
 * 用法：
 *   node install.js              安装
 *   node install.js --dry-run    只看会改哪些文件，不动手
 *   node install.js --restore    从 .bak-dshfix 还原
 *   node install.js --target=<插件目录>
 *
 * 无第三方依赖，只用 node 内置模块。
 */
import { execFileSync } from "node:child_process";
import {
  copyFileSync,
  existsSync,
  readFileSync,
  readdirSync,
  realpathSync,
  writeFileSync,
} from "node:fs";
import { basename, dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const HERE = dirname(fileURLToPath(import.meta.url));
const PAYLOAD = join(HERE, "payload", "lib");
const BACKUP_SUFFIX = ".bak-dshfix";
/** 本分发包自己的名字与版本。 */
const KIT_NAME = "dsh-workbuddy-connect-alter";
const KIT_VERSION = "1.0.0";
/** 本包适配的上游插件版本（不是本包的版本）。 */
const UPSTREAM_NAME = "dsh-workbuddy-connect";
const EXPECTED_VERSION = "0.7.9";

/** 每个文件必须出现的补丁标记：装完逐条核对，防止“复制成功但其实没生效”。 */
const MARKERS = {
  "index.js": ["WorkBuddyAccountBook", "pooledCredits", "FAILOVER_ATTEMPTS"],
  "client.js": ["accountsSubtotal", "creditsPool", "creditHeadline"],
  "host-heartbeat-SJaZ33tR.js": [
    "normalizeDeveloperRole",
    "sanitizeChannelFingerprint",
    "demoteSystemMessages",
    "demotionArmedUntilMs",
    "withoutStandingInstructions",
  ],
};

const args = process.argv.slice(2);
const flag = (name) => args.includes(`--${name}`);
const value = (name) => {
  const hit = args.find((arg) => arg.startsWith(`--${name}=`));
  return hit === undefined ? void 0 : hit.slice(name.length + 3);
};

const say = (text = "") => process.stdout.write(`${text}\n`);
const ok = (text) => say(`  [OK]   ${text}`);
const warn = (text) => say(`  [注意] ${text}`);
const bad = (text) => say(`  [失败] ${text}`);

function fail(text, hint) {
  say("");
  bad(text);
  if (hint !== undefined) say(`         ${hint}`);
  say("");
  process.exit(1);
}

/** 把插件目录归一化到真实路径（node_modules 里通常是个软链）。 */
function normalizeTarget(path) {
  try {
    return realpathSync(path);
  } catch {
    return path;
  }
}

function pluginRootOf(libPathOrRoot) {
  const root = basename(libPathOrRoot) === "lib" ? dirname(libPathOrRoot) : libPathOrRoot;
  return normalizeTarget(root);
}

function candidates() {
  const list = [];
  const explicit = value("target") ?? process.env.DSH_WBC_TARGET;
  if (explicit !== void 0) list.push(explicit);

  const appData = process.env.APPDATA ?? "";
  const profiles = appData === "" ? void 0 : join(appData, "dsh-desktop", "harness", "profiles");
  if (profiles !== void 0 && existsSync(profiles)) {
    const web = join(profiles, "web", "node_modules", "dsh-workbuddy-connect");
    if (existsSync(web)) list.push(web);
    // 其它 profile 里也装过的情况：按目录名扫一遍
    try {
      for (const entry of readdirSync(profiles)) {
        const other = join(profiles, entry, "node_modules", "dsh-workbuddy-connect");
        if (existsSync(other)) list.push(other);
      }
      // 兜底：直接从 generations 里找当前 live 的那份
      const generations = join(profiles, ".generations", "live");
      if (existsSync(generations)) {
        for (const entry of readdirSync(generations)) {
          if (!entry.startsWith("dsh-workbuddy-connect+")) continue;
          const built = join(generations, entry, "node_modules", "dsh-workbuddy-connect");
          if (existsSync(built)) list.push(built);
        }
      }
    } catch {
      /* 目录读不到就跳过，靠上面的精确路径 */
    }
  }
  const seen = new Set();
  const unique = [];
  for (const item of list) {
    const resolved = pluginRootOf(item);
    if (seen.has(resolved)) continue;
    seen.add(resolved);
    unique.push(resolved);
  }
  return unique;
}

function readVersion(root) {
  try {
    const pkg = JSON.parse(readFileSync(join(root, "package.json"), "utf8"));
    return typeof pkg.version === "string" ? pkg.version : "?";
  } catch {
    return void 0;
  }
}

function checkSyntax(file) {
  try {
    execFileSync(process.execPath, ["--check", file], { stdio: "pipe" });
    return true;
  } catch (error) {
    const detail = String(error.stderr ?? error.message ?? error).trim().split("\n").slice(0, 3).join(" / ");
    warn(`语法检查未通过：${basename(file)} — ${detail}`);
    return false;
  }
}

function install(root) {
  const lib = join(root, "lib");
  const version = readVersion(root);
  const dry = flag("dry-run");
  const files = Object.keys(MARKERS);
  const missing = files.filter((name) => !existsSync(join(PAYLOAD, name)));
  if (missing.length > 0) fail(`payload 不完整，缺少：${missing.join(", ")}`, "把压缩包解压完整再运行。");

  say("");
  say(`插件目录：${lib}`);
  say(`已装版本：${UPSTREAM_NAME} ${version ?? "(读不到 package.json)"}`);
  say(`本包版本：${KIT_NAME} ${KIT_VERSION}（改自 ${UPSTREAM_NAME} ${EXPECTED_VERSION}）`);
  if (version !== EXPECTED_VERSION) {
    say("");
    warn(`版本不一致（本机 ${version ?? "?"}，本包按 ${EXPECTED_VERSION} 制作）。`);
    warn("这个插件每个版本都会重新构建，文件名里的哈希和代码结构可能都变了，");
    warn("强行覆盖有把插件弄坏的风险。建议先把插件升降级到 0.7.9，再把版本号发我适配。");
    if (!flag("force")) {
      say("");
      say("确认要强行装的话：node install.js --force");
      process.exit(2);
    }
  }

  say("");
  let backedUp = 0;
  let copied = 0;
  let added = 0;

  for (const name of files) {
    const target = join(lib, name);
    const source = join(PAYLOAD, name);
    const backup = target + BACKUP_SUFFIX;
    const exists = existsSync(target);
    if (dry) {
      say(`  将${exists ? "覆盖" : "新增"} ${name}${!exists || existsSync(backup) ? "" : "（会先备份）"}`);
      continue;
    }
    // 上游构建的 chunk 文件名带哈希；这里以补丁包内的文件名为准。
    // 目标里没有同名文件时属于「新增」，照样写入 —— index.js 引用的就是这个名字。
    if (exists && !existsSync(backup)) {
      copyFileSync(target, backup);
      backedUp += 1;
    }
    copyFileSync(source, target);
    if (exists) copied += 1;
    else added += 1;
  }

  if (dry) {
    say("");
    say("（--dry-run，未改动任何文件）");
    return 0;
  }

  say("");
  say("核对补丁标记：");
  let markerFail = 0;
  for (const name of files) {
    const target = join(lib, name);
    if (!existsSync(target)) continue;
    const text = readFileSync(target, "utf8");
    const absent = MARKERS[name].filter((mark) => !text.includes(mark));
    if (absent.length > 0) {
      markerFail += 1;
      bad(`${name} 缺少：${absent.join(", ")}`);
    } else {
      ok(`${name} 全部就位`);
    }
  }

  say("");
  say("语法检查：");
  let syntaxFail = 0;
  for (const name of files) {
    const target = join(lib, name);
    if (!existsSync(target)) continue;
    if (checkSyntax(target)) ok(name);
    else syntaxFail += 1;
  }

  say("");
  if (copied + added === 0) {
    bad("没有复制任何文件。");
    return 1;
  }
  say(`完成：覆盖 ${copied} 个、新增 ${added} 个文件，新建备份 ${backedUp} 个（后缀 ${BACKUP_SUFFIX}）。`);
  if (markerFail > 0 || syntaxFail > 0) {
    say("");
    bad("有文件没通过核对，建议先还原：node install.js --restore");
    return 1;
  }
  say("");
  say("下一步：");
  say("  1. 完全退出 DSH 桌面端（不是最小化），再重新打开；");
  say("  2. 打开设置里的 WorkBuddy 插件卡片，确认出现「账号」区块和积分合计；");
  say("  3. 输入框右下角积分应等于所有账号之和。");
  say("");
  say("插件升级/重装后会覆盖这些改动，届时重新运行一次本安装器即可。");
  return 0;
}

function restore(root) {
  const lib = join(root, "lib");
  say("");
  say(`插件目录：${lib}`);
  say("");
  let restored = 0;
  let absent = 0;
  for (const name of Object.keys(MARKERS)) {
    const target = join(lib, name);
    const backup = target + BACKUP_SUFFIX;
    if (!existsSync(backup)) {
      absent += 1;
      continue;
    }
    copyFileSync(backup, target);
    restored += 1;
    ok(`已还原 ${name}`);
  }
  say("");
  if (restored === 0) {
    warn("没有找到任何 .bak-dshfix 备份，无需还原。");
    return 0;
  }
  say(`完成：还原 ${restored} 个文件${absent > 0 ? `，${absent} 个没有备份` : ""}。重启 DSH 生效。`);
  return 0;
}

function main() {
  say("");
  say(`${KIT_NAME} ${KIT_VERSION}`);
  say("改自 dsh-workbuddy-connect 0.7.9（corrinehu，MIT）· 非官方发行版");
  say("========================================================");
  say("功能：解除上游 11128 拦截 / 多账号额度叠加 / 积分合计显示");

  const found = candidates();
  if (found.length === 0) {
    fail(
      "没找到已安装的 dsh-workbuddy-connect 插件。",
      `先在 DSH 桌面端的插件市场安装 ${UPSTREAM_NAME}（${EXPECTED_VERSION}），再运行本安装器；或用 --target=<插件目录> 指定路径。`,
    );
  }
  const usable = found.filter((root) => existsSync(join(root, "lib", "index.js")));
  if (usable.length === 0) {
    fail("找到插件目录，但里面没有 lib/index.js。", "插件可能没装完整，先在 DSH 里重装一次。");
  }
  if (usable.length > 1) {
    say("");
    warn("检测到多份安装，默认处理第一份（当前 web profile 用的那份）：");
    for (const root of usable) say(`         ${root}（${readVersion(root) ?? "?"}）`);
    say("        其它 profile 需要的话，用 --target=<路径> 单独再跑一次。");
  }

  const root = pluginRootOf(usable[0]);
  return flag("restore") ? restore(root) : install(root);
}

process.exit(main());
